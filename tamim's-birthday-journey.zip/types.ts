export type StepProps = {
  onNext: () => void;
  isActive: boolean;
};

export interface BackgroundProps {
  isCelebrating: boolean;
}