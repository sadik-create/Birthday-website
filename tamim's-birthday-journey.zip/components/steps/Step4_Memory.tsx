import React, { useRef } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { StepProps } from '../../types';
import { Button } from '../ui/Button';

export const Step4_Memory: React.FC<StepProps> = ({ onNext }) => {
  const ref = useRef<HTMLDivElement>(null);

  // Mouse tilt logic
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const mouseXSpring = useSpring(x);
  const mouseYSpring = useSpring(y);

  const rotateX = useTransform(mouseYSpring, [-0.5, 0.5], ["15deg", "-15deg"]);
  const rotateY = useTransform(mouseXSpring, [-0.5, 0.5], ["-15deg", "15deg"]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    const xPct = mouseX / width - 0.5;
    const yPct = mouseY / height - 0.5;
    x.set(xPct);
    y.set(yPct);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <div className="flex flex-col items-center justify-center text-center p-4 w-full">
      <motion.h2
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl font-bold mb-8 text-gradient"
      >
        That One Time...
      </motion.h2>

      {/* 3D Container */}
      <div 
        className="perspective-1000 mb-10"
        style={{ perspective: 1000 }}
      >
        <motion.div
          ref={ref}
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          style={{
            rotateX,
            rotateY,
            transformStyle: "preserve-3d",
          }}
          initial={{ rotate: -5, opacity: 0, scale: 0.8 }}
          animate={{ rotate: -5, opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="relative bg-white p-4 pb-16 shadow-2xl rounded-sm max-w-sm cursor-pointer"
        >
          {/* Tape effect */}
          <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-32 h-8 bg-white/30 backdrop-blur-sm transform -rotate-2 shadow-sm border border-white/20 z-10"></div>
          
          {/* Image */}
          <div className="aspect-[3/4] overflow-hidden bg-gray-100 mb-4 border border-gray-100">
             <img 
              src="https://uploads.onecompiler.io/44638bvqy/44638c2p3/IMG-20251129-WA0007.jpg" 
              alt="Our favorite memory" 
              className="w-full h-full object-cover pointer-events-none"
             />
          </div>
          
          {/* Caption */}
          <div className="absolute bottom-4 left-0 right-0 text-center">
             <p className="font-['Playfair_Display'] text-gray-800 text-xl italic">Our favorite memory</p>
          </div>
          
          {/* Gloss overlay */}
          <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent pointer-events-none rounded-sm"></div>
        </motion.div>
      </div>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="text-xl text-neutral-300 max-w-md mb-10"
      >
        Every moment with you feels like a scene from a movie I'd watch on repeat.
      </motion.p>

      <Button onClick={onNext}>One last thing...</Button>
    </div>
  );
};