import React from 'react';
import { motion } from 'framer-motion';
import { StepProps } from '../../types';
import { Button } from '../ui/Button';

export const Step2_Message: React.FC<StepProps> = ({ onNext }) => {
  return (
    <div className="flex flex-col items-center justify-center text-center p-8 max-w-xl mx-auto">
      <motion.div
        initial={{ rotate: -45, scale: 0 }}
        animate={{ rotate: 0, scale: 1 }}
        transition={{ duration: 0.8, type: 'spring' }}
        className="text-8xl mb-8"
      >
        🎉
      </motion.div>

      <motion.h1
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="text-5xl md:text-6xl font-bold mb-8 text-gradient"
      >
        Happy Birthday!
      </motion.h1>

      <motion.p
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="text-xl md:text-2xl text-neutral-200 leading-relaxed mb-10 font-light"
      >
        Another year of you making the world brighter. Your existence is a gift, and I'm so lucky to witness it.
      </motion.p>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
      >
        <Button onClick={onNext}>There's more...</Button>
      </motion.div>
    </div>
  );
};