import React from 'react';
import { motion } from 'framer-motion';
import { StepProps } from '../../types';
import { Button } from '../ui/Button';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2
    }
  }
};

const item = {
  hidden: { y: 20, opacity: 0 },
  show: { y: 0, opacity: 1 }
};

export const Step3_Reasons: React.FC<StepProps> = ({ onNext }) => {
  return (
    <div className="flex flex-col items-center justify-center w-full max-w-4xl mx-auto p-4 md:p-8">
      <motion.h2
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-3xl md:text-4xl font-bold mb-8 text-gradient text-center"
      >
        A Few Things I Adore About You
      </motion.h2>

      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full mb-10"
      >
        {/* Card 1: Wide */}
        <motion.div variants={item} className="md:col-span-2 p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md hover:bg-white/10 transition-colors">
          <h3 className="text-xl font-bold text-pink-300 mb-2">✨ Your Unmatched Kindness</h3>
          <p className="text-neutral-300">The genuine warmth you show to everyone is something truly rare and beautiful. You have this ability to make people feel safe.</p>
        </motion.div>

        {/* Card 2: Small */}
        <motion.div variants={item} className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md hover:bg-white/10 transition-colors">
          <h3 className="text-xl font-bold text-purple-300 mb-2">😊 That Smile</h3>
          <p className="text-neutral-300">It's honestly a work of art. It lights up the entire room.</p>
        </motion.div>

         {/* Card 3: Small/Medium (Actually spans 2 on mobile, 1 on desktop? Prompt said large for 3rd, lets make it span 2 again or keep flexible) */}
         {/* Prompt said: Card 3 (Larger, spans two columns) */}
        <motion.div variants={item} className="md:col-span-2 p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md hover:bg-white/10 transition-colors">
          <h3 className="text-xl font-bold text-amber-300 mb-2">🌟 Your Radiant Spirit</h3>
          <p className="text-neutral-300">Your passion for life is infectious. Being around you makes everything feel more exciting and possible. You inspire me.</p>
        </motion.div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
      >
        <Button onClick={onNext}>Remember this?</Button>
      </motion.div>
    </div>
  );
};