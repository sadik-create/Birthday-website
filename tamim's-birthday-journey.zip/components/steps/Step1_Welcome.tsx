import React from 'react';
import { motion } from 'framer-motion';
import { StepProps } from '../../types';
import { Button } from '../ui/Button';

export const Step1_Welcome: React.FC<StepProps> = ({ onNext }) => {
  return (
    <div className="flex flex-col items-center justify-center text-center p-8 max-w-lg mx-auto">
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8, type: 'spring' }}
        className="text-8xl mb-6 filter drop-shadow-[0_0_15px_rgba(236,72,153,0.5)]"
      >
        <motion.div animate={{ scale: [1, 1.1, 1] }} transition={{ duration: 1.5, repeat: Infinity }}>
          ❤️
        </motion.div>
      </motion.div>

      <motion.h1
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="text-5xl md:text-6xl font-bold mb-6 text-gradient"
      >
        Hey Tamim,
      </motion.h1>

      <motion.p
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="text-xl text-neutral-300 leading-relaxed mb-10"
      >
        I built a little world for you, just to bring a smile to your face on your special day.
      </motion.p>

      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.7 }}
      >
        <Button onClick={onNext}>Let's Begin</Button>
      </motion.div>
    </div>
  );
};