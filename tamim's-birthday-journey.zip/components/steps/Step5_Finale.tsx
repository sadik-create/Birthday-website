import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { StepProps } from '../../types';
import { Button } from '../ui/Button';
import confetti from 'canvas-confetti';

export const Step5_Finale: React.FC<StepProps> = () => {
  const [celebrated, setCelebrated] = useState(false);

  const handleCelebrate = () => {
    setCelebrated(true);

    // Initial Burst
    const duration = 5 * 1000;
    const animationEnd = Date.now() + duration;
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 0 };

    const randomInRange = (min: number, max: number) => Math.random() * (max - min) + min;

    // Heart Emoji Confetti
    const heartInterval = window.setInterval(() => {
      const timeLeft = animationEnd - Date.now();
      if (timeLeft <= 0) return clearInterval(heartInterval);
      
      confetti({
        ...defaults,
        particleCount: 20,
        scalar: 2, // Larger emojis
        shapes: ['circle'], // Placeholder, emojis handled by shape or text below
        // Actually canvas-confetti creates standard shapes. For emojis we need custom shape or just accept colors.
        // Let's stick to standard confetti but specific colors
        colors: ['#FFC0CB', '#FF69B4', '#FF1493', '#C71585']
      });
      // Emoji hack using scalar
    }, 250);

    // Side Cannons
    const interval: any = setInterval(function() {
      const timeLeft = animationEnd - Date.now();

      if (timeLeft <= 0) {
        return clearInterval(interval);
      }

      const particleCount = 50 * (timeLeft / duration);
      // since particles fall down, start a bit higher than random
      confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 } });
      confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 } });
    }, 250);
  };

  return (
    <div className="flex flex-col items-center justify-center text-center p-8 max-w-xl mx-auto">
      <AnimatePresence mode="wait">
        {!celebrated ? (
          <motion.div
            key="wishes"
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: 0.5 }}
            className="flex flex-col items-center"
          >
             <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring" }}
                className="text-8xl mb-6"
             >
                🎂
             </motion.div>

            <motion.h2
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              className="text-4xl md:text-5xl font-bold mb-8 text-gradient"
            >
              My Wish For You
            </motion.h2>

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="text-xl text-neutral-200 leading-relaxed mb-10"
            >
              May the next year bring you all the love, success, and pure happiness you so rightfully deserve. May your dreams soar higher than ever.
            </motion.p>

            <Button onClick={handleCelebrate}>Celebrate!</Button>
          </motion.div>
        ) : (
          <motion.div
            key="celebration"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.5 }}
            className="flex flex-col items-center z-50"
          >
            <h1 className="text-6xl md:text-8xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-pink-400 via-purple-400 to-indigo-400 filter drop-shadow-[0_0_20px_rgba(255,255,255,0.3)]">
              Happy Birthday<br/>Tamim! ❤️
            </h1>
            <p className="text-2xl text-white/80 font-light mt-4">
              Best Friends Forever.
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};