import React from 'react';
import { motion } from 'framer-motion';

export const StepCard: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <motion.div 
        className="glass-card rounded-[40px] p-2 md:p-8 w-full max-w-4xl mx-4 min-h-[500px] flex items-center justify-center relative overflow-hidden"
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -50, scale: 0.95 }}
        transition={{ duration: 0.6, ease: "easeInOut" }}
    >
      <div className="relative z-10 w-full">
        {children}
      </div>
      
      {/* Subtle shine effect inside card */}
      <div className="absolute top-0 right-0 w-[300px] h-[300px] bg-white/5 blur-[80px] rounded-full pointer-events-none -translate-y-1/2 translate-x-1/2"></div>
    </motion.div>
  );
};