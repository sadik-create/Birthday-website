import React from 'react';
import { motion } from 'framer-motion';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  variant?: 'primary' | 'disabled';
}

export const Button: React.FC<ButtonProps> = ({ children, onClick, variant = 'primary', ...props }) => {
  if (variant === 'disabled') {
    return (
      <button
        disabled
        className="px-8 py-3 rounded-full bg-neutral-800 text-neutral-500 font-bold text-lg cursor-not-allowed opacity-50 transition-all duration-500"
        {...props}
      >
        {children}
      </button>
    );
  }

  return (
    <motion.button
      whileHover={{ scale: 1.05, y: -2 }}
      whileTap={{ scale: 0.95, y: 0 }}
      onClick={onClick}
      className="relative px-8 py-3 rounded-full bg-gradient-to-r from-pink-500 to-rose-600 text-white font-bold text-lg shadow-[0_0_20px_rgba(244,63,94,0.4)] hover:shadow-[0_0_35px_rgba(244,63,94,0.6)] transition-all duration-300 group overflow-hidden"
      {...props}
    >
      <span className="relative z-10">{children}</span>
      <div className="absolute inset-0 bg-white/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
    </motion.button>
  );
};