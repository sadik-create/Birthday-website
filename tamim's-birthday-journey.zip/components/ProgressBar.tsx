import React from 'react';
import { motion } from 'framer-motion';

export const ProgressBar: React.FC<{ progress: number }> = ({ progress }) => {
  return (
    <div className="fixed top-0 left-0 right-0 h-2 bg-white/5 backdrop-blur-sm z-50">
      <motion.div 
        className="h-full bg-gradient-to-r from-pink-500 via-red-500 to-purple-600 shadow-[0_0_10px_rgba(236,72,153,0.5)]"
        initial={{ width: "0%" }}
        animate={{ width: `${progress}%` }}
        transition={{ duration: 1, ease: "easeInOut" }}
      />
    </div>
  );
};