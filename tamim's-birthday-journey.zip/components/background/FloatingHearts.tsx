import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, Instance, Instances } from '@react-three/drei';
import * as THREE from 'three';

const HeartShape = () => {
  const shape = useMemo(() => {
    const x = 0, y = 0;
    const heartShape = new THREE.Shape();
    heartShape.moveTo(x + 5, y + 5);
    heartShape.bezierCurveTo(x + 5, y + 5, x + 4, y, x, y);
    heartShape.bezierCurveTo(x - 6, y, x - 6, y + 7, x - 6, y + 7);
    heartShape.bezierCurveTo(x - 6, y + 11, x - 3, y + 15.4, x + 5, y + 19);
    heartShape.bezierCurveTo(x + 12, y + 15.4, x + 16, y + 11, x + 16, y + 7);
    heartShape.bezierCurveTo(x + 16, y + 7, x + 16, y, x + 10, y);
    heartShape.bezierCurveTo(x + 7, y, x + 5, y + 5, x + 5, y + 5);
    return heartShape;
  }, []);
  return shape;
};

const FloatingHeart = ({ position, scale, speed, rotationSpeed }: { position: [number, number, number], scale: number, speed: number, rotationSpeed: number }) => {
  const ref = useRef<THREE.Group>(null);
  
  useFrame((state) => {
    if (ref.current) {
        // Subtle drift
        ref.current.rotation.y += rotationSpeed * 0.01;
        ref.current.rotation.z += rotationSpeed * 0.005;
        // Bobbing
        ref.current.position.y += Math.sin(state.clock.elapsedTime * speed) * 0.01;
    }
  });

  return (
    <group ref={ref} position={position}>
      <Float speed={speed} rotationIntensity={0.5} floatIntensity={0.5}>
         {/* We use a Mesh for a single heart, simplified from Instances for easier control of individual props if needed later */}
         <mesh scale={scale} rotation={[0, 0, Math.PI]}>
            <extrudeGeometry args={[HeartShape(), { depth: 4, bevelEnabled: true, bevelSegments: 2, steps: 2, bevelSize: 1, bevelThickness: 1 }]} />
            <meshStandardMaterial 
                color="#db2777" 
                emissive="#9d174d"
                emissiveIntensity={0.2}
                roughness={0.3}
                metalness={0.1}
            />
         </mesh>
      </Float>
    </group>
  );
};

export const FloatingHearts: React.FC<{ isCelebrating: boolean }> = ({ isCelebrating }) => {
  const count = 25;
  const hearts = useMemo(() => {
    return new Array(count).fill(0).map(() => ({
      position: [
        (Math.random() - 0.5) * 30, // x
        (Math.random() - 0.5) * 30, // y
        (Math.random() - 0.5) * 15 - 5 // z (push back slightly)
      ] as [number, number, number],
      scale: 0.03 + Math.random() * 0.04,
      speed: 0.5 + Math.random(),
      rotationSpeed: Math.random()
    }));
  }, []);

  return (
    <div className="fixed inset-0 z-[1] pointer-events-none">
      <Canvas camera={{ position: [0, 0, 15], fov: 45 }}>
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} intensity={1} color="#f9a8d4" />
        <pointLight position={[-10, -10, -10]} intensity={0.5} color="#818cf8" />
        
        <group>
            {hearts.map((heart, i) => (
               <FloatingHeart 
                  key={i} 
                  {...heart} 
                /> 
            ))}
        </group>
      </Canvas>
    </div>
  );
};