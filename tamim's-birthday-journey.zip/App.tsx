import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'framer-motion';
import { Aurora } from './components/background/Aurora';
import { FloatingHearts } from './components/background/FloatingHearts';
import { StepCard } from './components/StepCard';
import { ProgressBar } from './components/ProgressBar';
import { Step1_Welcome } from './components/steps/Step1_Welcome';
import { Step2_Message } from './components/steps/Step2_Message';
import { Step3_Reasons } from './components/steps/Step3_Reasons';
import { Step4_Memory } from './components/steps/Step4_Memory';
import { Step5_Finale } from './components/steps/Step5_Finale';

const App: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const totalSteps = 5;

  const nextStep = () => {
    if (currentStep < totalSteps - 1) {
      setCurrentStep((prev) => prev + 1);
    }
  };

  const progress = ((currentStep + 1) / totalSteps) * 100;

  // Render the specific step component based on state
  const renderStep = () => {
    switch (currentStep) {
      case 0: return <Step1_Welcome onNext={nextStep} isActive={currentStep === 0} />;
      case 1: return <Step2_Message onNext={nextStep} isActive={currentStep === 1} />;
      case 2: return <Step3_Reasons onNext={nextStep} isActive={currentStep === 2} />;
      case 3: return <Step4_Memory onNext={nextStep} isActive={currentStep === 3} />;
      case 4: return <Step5_Finale onNext={nextStep} isActive={currentStep === 4} />;
      default: return null;
    }
  };

  // Special case: When step is 4 (Finale) and celebrating, we might want to hide hearts or animate them out.
  // The component FloatingHearts can handle this logic if we pass a prop.
  const isCelebrating = currentStep === 4; 

  return (
    <div className="relative min-h-screen w-full flex items-center justify-center text-white overflow-hidden">
      
      {/* Background Layers */}
      <Aurora />
      <FloatingHearts isCelebrating={isCelebrating} />

      {/* UI Overlay */}
      <ProgressBar progress={progress} />

      {/* Main Content Area */}
      <div className="relative z-10 w-full max-w-5xl flex justify-center">
        <AnimatePresence mode="wait">
          <StepCard key={currentStep}>
            {renderStep()}
          </StepCard>
        </AnimatePresence>
      </div>

      {/* Footer / Copyright / Simple Signoff */}
      <div className="fixed bottom-4 text-center w-full z-10 opacity-30 text-xs font-light tracking-widest pointer-events-none">
        DESIGNED FOR TAMIM
      </div>
    </div>
  );
};

export default App;